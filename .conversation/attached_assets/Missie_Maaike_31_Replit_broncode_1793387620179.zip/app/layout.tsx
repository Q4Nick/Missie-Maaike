import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Missie Maaike 31 — Top Secret",
  description: "Vier agenten, 31 missies en een geheime verjaardagsbestemming.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="nl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
