# Missie Maaike 31 — broncode voor Replit

Dit project is geen losse statische HTML-pagina: het is een React/Next-achtige
website (Vinext) met een server-API en centrale SQL-database. Daardoor kunnen
Michel, Tiny, Nynke en Younes ieder op hun eigen telefoon spelen en kan de
spelleider hun status tegelijk zien.

## Belangrijkste bestanden

- `app/page.tsx` — de interface (de HTML-achtige JSX) met spel, minigames en dashboard.
- `app/globals.css` — kleuren, fonts, responsive styling.
- `lib/game.ts` — namen, persoonlijke agentcodes, 31 vragen, antwoorden, hints en tijdsloten.
- `app/api/game/route.ts` — controle van codes en antwoorden; gezamenlijke blokkade om 15:00.
- `db/schema.ts` en `drizzle/` — databaseopzet.
- `.openai/hosting.json` — configuratie van de oorspronkelijke hosting; niet nodig op Replit.

## Overzetten naar Replit

1. Maak een nieuwe Replit met Node.js/Next.js en importeer de inhoud van dit ZIP-bestand.
2. Installeer de afhankelijkheden uit `package.json`.
3. Deze versie gebruikt **Cloudflare D1** via `cloudflare:workers` voor de live antwoorden. Die binding werkt niet automatisch op Replit. Pas `app/api/game/route.ts` aan om Replit's database of een andere centrale SQLite/Postgres-database te gebruiken.
4. Maak een server-side secret `ADMIN_CODE` aan; bewaar dit niet in client-side JavaScript.
5. Draai de SQL-migratie uit `drizzle/0000_productive_harrier.sql`.
6. Start de webserver met het relevante startcommando voor de gekozen Replit-runtime.

**Let op:** het is dus geen kant-en-klare, direct uitvoerbare Replit-import
zonder de databaseaanpassing. Alle schermen, teksten, puzzels en logica zijn
wel beschikbaar als bewerkbare broncode.

## Ingestelde feiten

- Speeldatum: zaterdag 31 oktober 2026, 12:00–18:15 (Nederlandse tijd).
- Groepsopdracht 15:00: vier persoonlijke antwoorden vormen **26/10/2026**.
- Na 15:00 blijven volgende opdrachten gesloten tot alle vier juist hebben geantwoord.
- Tussenstop vanaf 17:45: 3641 CK, huisnummer 65, Mijdrecht.
- Eindbestemming vanaf 18:15: Nixtamal, Mijdrecht.

## Codes

- Michel / Alpha: `M31-ALPHA-7K`
- Tiny / Bravo: `M31-BRAVO-4Q`
- Nynke / Charlie: `M31-CHARLIE-9X`
- Younes / Delta: `M31-DELTA-2P`

De beheerderscode stel je zelf als server-side secret in. De oude waarde
zit bewust niet in het ZIP-bestand.
