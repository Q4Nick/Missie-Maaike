CREATE TABLE `answers` (
	`agent` text NOT NULL,
	`puzzle` integer NOT NULL,
	`answer` text NOT NULL,
	`correct` integer NOT NULL,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`agent`, `puzzle`)
);
