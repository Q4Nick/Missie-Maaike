import { sqliteTable, text, integer, primaryKey } from 'drizzle-orm/sqlite-core';
export const answers = sqliteTable('answers', {
  agent: text('agent').notNull(),
  puzzle: integer('puzzle').notNull(),
  answer: text('answer').notNull(),
  correct: integer('correct').notNull(),
  updatedAt: integer('updated_at').notNull(),
}, t => [primaryKey({ columns: [t.agent,t.puzzle] })]);
